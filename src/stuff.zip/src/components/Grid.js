import React, { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import PropTypes from 'prop-types'
import _ from 'lodash'

import Cell from './Cell.js'
import { evolveWorld } from '../state/actions'
import './Grid.css'

const Grid = ({ width, height, evolveWorldOnClick }) => {
  const [evolving, setEvolving] = useState(false)

  useEffect(() => {
    const interval = setInterval(() => {
      if (evolving) {
        evolveWorldOnClick()
      }
    }, 500)

    return function cleanup () {
      clearInterval(interval)
    }
  })

  return (
    <div className="Grid">
      <header className="Grid-header">
        <table className="Grid-table">
          <tbody>
            {_.range(0, height).map(y =>
              <tr key={y}>
                {_.range(0, width).map(x =>
                  <Cell key={x} x={x} y={y}/>)}
              </tr>
            )}
          </tbody>
        </table>
        <button onClick={() => setEvolving(!evolving)}>{evolving ? 'Stop' : 'Go'}</button>
      </header>
    </div>
  )
}

Grid.propTypes = {
  width: PropTypes.number,
  height: PropTypes.number,
  evolveWorldOnClick: PropTypes.func
}

const mapStateToProps = (state) => ({})
const mapDispatchToProps = (dispatch) => ({
  evolveWorldOnClick: () => dispatch(evolveWorld())
})

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Grid)
